const { MongoClient, ServerApiVersion } = require('mongodb');

async function connectToMongoDB(){
    const uri = "mongodb+srv://deniszeksenov03:123456asd@cluster0.m2dbzhu.mongodb.net/soup";

    const client = new MongoClient(uri, {
      serverApi: {
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true,
      }
    });
    await client.connect();
   
    await client.db("admin").command({ ping: 1 });
    console.log("Pinged your deployment. You successfully connected to MongoDB!");
    return uri
}

module.exports = connectToMongoDB