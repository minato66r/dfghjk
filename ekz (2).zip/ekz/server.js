const express = require('express');
const mongoose = require('mongoose');
const app = express();
const connectToMongoDB = require('./connetion');
//модель пользователя 
const path = require('path');

const session = require('express-session');
const MongoDBStore = require('connect-mongodb-session')(session);

const store = new MongoDBStore({
    uri: 'mongodb+srv://admin:admin@cluster0.srfsgmv.mongodb.net/mySite',
    collection: 'sessions'
})
app.use(session({
    secret:'secret key',
    resave:false,
    saveUninitialized:false,
    store: store
}));

app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.urlencoded({ extended: true }));



app.get('/', (req, res) => {
    res.render('index',{session: req.session});
});


app.get('/logout', function(req,res){
    req.session.destroy(function(err){
        if(err){
            console.log(err)
        }else{
            res.redirect('/login');
        }
    });
});
function requireLogin(req, res, next) {
    if( req.session && req.session.userId){
        return next();
    } else{
        return res.redirect('/login');
    }
}

 
async function start() {
    const uri = await connectToMongoDB();
    await mongoose.connect(uri, { useNewUrlparser: true, useUnifiedTopology: true });
    app.listen(3000, () => {
        console.log('сервер запущен на порту 3000');
    });
}

start();