const express = require('express');
const router = express.Router();

const LoginController = require('../controlles/loginController');

router.get ('/register', (req, res)=> {
    res.render('register');
});

router.post('/register', registerController.register);

module.exports = router;




app.get('/register', async (req, res) => {
    res.render('register')
});



