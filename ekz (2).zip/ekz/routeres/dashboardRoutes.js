const express = require('express');
const router = express.Router();

app.get('/dashboard', requireLogin, function(req,res){
    res.render('dasboard', {session:req.session});
});