const bcrypt = require('bcryptjs')
const User = require('./user');

async function login(req, res)  {
    app.post('/register', async (req, res) => {
        const { email, password } = req.body;
    
        if (!email || !password) {
            return res.status(400).send('Введите email и пороль ');
        }
    
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).send('пользователь с таким email уже зарегистриван');
        }
        const hashedPassword = bcrypt.hashSync(password, 10);
    
        const user = new User({
            email,
            password: hashedPassword,
        })
    
        try {
            await user.save();
    
            res.send('вы успешно зарегестрировались');
        }
        catch (err) {
            console.log(user)
            res.status(500).send('Ошибка при сохронение пользователя в базе данных');
        }
        }
    );

module.exports = {
    register
 }};
