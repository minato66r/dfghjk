const bcrypt = require('bcryptjs')
const User = require('./user');

// app.get('/login', async (req, res) => {
//     res.render('login');
// });

 async function login(req, res)  {
    const {email,password} = req.body;

    if (!email || !password){
        return res.status(400).send('введите email и пороль');
    }
 const user = await User.findOne({ email});
 if (!user){
    return res.status(400).send ('Неверный email или пороль');
 }
 const isPasswordCorrect =bcrypt.compareSync(password,user.password);
 if(!isPasswordCorrect) {
    return res.status(400).send ('Неверный email или пороль');
    
 }
 req.session.isAuthenticated = true;
 req.session.user = {
    _id:user._id,
    email:user.email,
 };
 res.redirect('/');
};

module.exports = {
   login
};
